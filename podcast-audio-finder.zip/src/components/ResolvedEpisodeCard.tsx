import React, { useState, useEffect } from "react";
import {
  Copy,
  Check,
  ExternalLink,
  Download,
  FileAudio,
  Rss,
  Calendar,
  Clock,
  HardDrive,
  Info,
  Server,
  Share2,
  PlayCircle,
  FileText,
} from "lucide-react";
import { EpisodeInfo, PodcastInfo, AudioInspection } from "../types";
import { AudioPlayer } from "./AudioPlayer";

interface ResolvedEpisodeCardProps {
  episode: EpisodeInfo;
  podcast?: PodcastInfo;
}

export const ResolvedEpisodeCard: React.FC<ResolvedEpisodeCardProps> = ({
  episode,
  podcast,
}) => {
  const [copied, setCopied] = useState(false);
  const [feedCopied, setFeedCopied] = useState(false);
  const [inspection, setInspection] = useState<AudioInspection | null>(null);
  const [isInspecting, setIsInspecting] = useState(false);
  const [showFullDesc, setShowFullDesc] = useState(false);

  // Inspect audio stream headers on mount/change
  useEffect(() => {
    if (!episode.audioUrl) return;
    setIsInspecting(true);
    fetch("/api/inspect-audio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ audioUrl: episode.audioUrl }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setInspection(data);
        }
      })
      .catch((err) => console.warn("Failed to inspect audio:", err))
      .finally(() => setIsInspecting(false));
  }, [episode.audioUrl]);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(episode.audioUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleCopyFeed = () => {
    const feed = episode.feedUrl || podcast?.feedUrl;
    if (feed) {
      navigator.clipboard.writeText(feed);
      setFeedCopied(true);
      setTimeout(() => setFeedCopied(false), 2500);
    }
  };

  // Determine host CDN platform name
  const getCdnHostName = (url: string) => {
    try {
      const u = new URL(url);
      if (u.hostname.includes("podbean")) return "Podbean Cloud CDN";
      if (u.hostname.includes("megaphone")) return "Megaphone (Spotify)";
      if (u.hostname.includes("buzzsprout")) return "Buzzsprout CDN";
      if (u.hostname.includes("libsyn")) return "Libsyn Storage";
      if (u.hostname.includes("anchor") || u.hostname.includes("spotify")) return "Spotify / Anchor";
      if (u.hostname.includes("soundon")) return "SoundOn CDN";
      if (u.hostname.includes("firstory")) return "Firstory CDN";
      if (u.hostname.includes("cloudfront")) return "Amazon CloudFront";
      return u.hostname;
    } catch {
      return "Direct Audio Server";
    }
  };

  const formattedDate = episode.releaseDate
    ? new Date(episode.releaseDate).toLocaleDateString("zh-TW", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : "未知日期";

  return (
    <div className="space-y-6">
      {/* Main Success Container */}
      <div className="bg-slate-900 border-2 border-indigo-500/30 rounded-3xl overflow-hidden shadow-2xl">
        {/* Top Status Header */}
        <div className="bg-gradient-to-r from-indigo-950/80 via-slate-900 to-violet-950/80 border-b border-indigo-500/20 px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-3 w-3 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-emerald-400 font-semibold text-sm tracking-wide">
              音檔 MP3 來源位址已成功解析
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
            <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
              {inspection?.contentType || "audio/mpeg"}
            </span>
            {inspection?.formattedSize && inspection.formattedSize !== "Unknown" && (
              <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-300">
                {inspection.formattedSize}
              </span>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Episode Info Row */}
          <div className="flex flex-col md:flex-row gap-6 items-start">
            {/* Artwork */}
            {episode.artworkUrl ? (
              <img
                src={episode.artworkUrl}
                alt={episode.title}
                className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl object-cover shadow-xl border border-slate-700/80 shrink-0"
              />
            ) : (
              <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl bg-indigo-950 border border-indigo-700/50 flex flex-col items-center justify-center text-indigo-400 shrink-0">
                <FileAudio className="w-10 h-10 mb-1" />
                <span className="text-xs font-bold">AUDIO</span>
              </div>
            )}

            {/* Episode Title & Metadata */}
            <div className="flex-1 min-w-0 space-y-2.5">
              <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-slate-800 text-indigo-300 text-xs font-medium border border-slate-700">
                <span>{episode.podcastTitle || podcast?.title || "Podcast 節目"}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                {episode.title}
              </h3>

              {/* Meta details chips */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                {episode.releaseDate && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>發布時間：{formattedDate}</span>
                  </div>
                )}
                {episode.duration && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>長度：{episode.duration}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-slate-500" />
                  <span>伺服器：{getCdnHostName(episode.audioUrl)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Primary Highlight: MP3 Direct URL Box */}
          <div className="bg-slate-950 border-2 border-indigo-500/40 rounded-2xl p-4 sm:p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <FileAudio className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-bold text-indigo-300 tracking-wider uppercase">
                  MP3 音檔直鏈位址 (Direct Audio Source URL)
                </span>
              </div>

              <span className="text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded-full">
                公開直連 / 可直接下載
              </span>
            </div>

            {/* URL Display Field */}
            <div className="relative flex items-center bg-slate-900 border border-slate-800 rounded-xl p-3">
              <div className="font-mono text-xs sm:text-sm text-indigo-100 break-all select-all pr-2 leading-relaxed">
                {episode.audioUrl}
              </div>
            </div>

            {/* URL Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <button
                onClick={handleCopyUrl}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition shadow-md cursor-pointer ${
                  copied
                    ? "bg-emerald-600 text-white"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/20"
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>已複製 MP3 網址！</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>複製 MP3 網址</span>
                  </>
                )}
              </button>

              <a
                href={episode.audioUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 transition cursor-pointer"
              >
                <ExternalLink className="w-4 h-4 text-slate-400" />
                <span>在新分頁開啟</span>
              </a>

              <a
                href={`/api/download?url=${encodeURIComponent(episode.audioUrl)}&filename=${encodeURIComponent(
                  episode.title.replace(/[^\w\u4e00-\u9fa5\u3040-\u30ff.-]/g, "_") + ".mp3"
                )}`}
                download
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium text-indigo-300 bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/60 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>直接下載 MP3</span>
              </a>
            </div>
          </div>

          {/* Integrated Interactive Audio Player */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 px-1">
              <PlayCircle className="w-4 h-4 text-indigo-400" />
              <span>線上即時試聽 (Audio Player)</span>
            </div>
            <AudioPlayer
              audioUrl={episode.audioUrl}
              title={episode.title}
              artist={episode.podcastTitle || podcast?.title}
              artworkUrl={episode.artworkUrl || podcast?.artworkUrl}
              fileName={episode.title + ".mp3"}
            />
          </div>

          {/* Technical Specs & RSS Feed Link */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* Tech Specs */}
            <div className="bg-slate-950/80 border border-slate-800/90 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <Info className="w-4 h-4 text-indigo-400" />
                <span>音訊來源詳細技術規格</span>
              </div>
              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[11px]">音訊編碼格式</span>
                  <span className="text-slate-200 font-mono font-medium">MP3 (MPEG-1/2 Audio Layer 3)</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[11px]">串流 Content-Type</span>
                  <span className="text-emerald-400 font-mono font-medium">{inspection?.contentType || "audio/mpeg"}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[11px]">檔案大小 (預估)</span>
                  <span className="text-slate-200 font-mono font-medium">{inspection?.formattedSize || episode.fileSize || "約 8~15 MB"}</span>
                </div>
                <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-500 block text-[11px]">分段快取 (Range Request)</span>
                  <span className="text-indigo-300 font-mono font-medium">支援隨選播放 (bytes)</span>
                </div>
              </div>
            </div>

            {/* RSS Feed & Host details */}
            <div className="bg-slate-950/80 border border-slate-800/90 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                  <Rss className="w-4 h-4 text-amber-500" />
                  <span>原始 Podcast RSS 來源</span>
                </div>
                {(episode.feedUrl || podcast?.feedUrl) && (
                  <button
                    onClick={handleCopyFeed}
                    className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-medium transition cursor-pointer"
                  >
                    {feedCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{feedCopied ? "已複製" : "複製 RSS"}</span>
                  </button>
                )}
              </div>

              {(episode.feedUrl || podcast?.feedUrl) ? (
                <div className="space-y-2">
                  <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800 font-mono text-xs text-amber-200/90 break-all select-all">
                    {episode.feedUrl || podcast?.feedUrl}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Apple Podcasts 透過此 RSS Feed 的 <code className="text-indigo-300">&lt;enclosure&gt;</code> 標籤抓取 MP3 音檔。
                  </p>
                </div>
              ) : (
                <p className="text-xs text-slate-500">此單集已直接透過官方 API 抓取音訊位址。</p>
              )}
            </div>
          </div>

          {/* Episode Notes / Description */}
          {episode.description && (
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <FileText className="w-4 h-4 text-indigo-400" />
                <span>單集介紹 (Show Notes)</span>
              </div>
              <div
                className={`text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-line ${
                  !showFullDesc ? "line-clamp-4" : ""
                }`}
              >
                {episode.description}
              </div>
              {episode.description.length > 200 && (
                <button
                  onClick={() => setShowFullDesc(!showFullDesc)}
                  className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 pt-1 transition cursor-pointer"
                >
                  {showFullDesc ? "收合內容" : "展開完整單集介紹..."}
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
