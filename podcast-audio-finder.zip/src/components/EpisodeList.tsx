import React from "react";
import { Play, Download, Copy, Clock, Calendar, Check, ExternalLink, Music } from "lucide-react";
import { EpisodeInfo } from "../types";

interface EpisodeListProps {
  episodes: EpisodeInfo[];
  currentEpisodeId?: string | number;
  onSelectEpisode: (episode: EpisodeInfo) => void;
  podcastTitle?: string;
}

export const EpisodeList: React.FC<EpisodeListProps> = ({
  episodes,
  currentEpisodeId,
  onSelectEpisode,
  podcastTitle,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | number | null>(null);

  if (!episodes || episodes.length === 0) return null;

  const handleCopy = (e: React.MouseEvent, episode: EpisodeInfo) => {
    e.stopPropagation();
    navigator.clipboard.writeText(episode.audioUrl);
    setCopiedId(episode.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 shadow-xl">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-white">
            {podcastTitle ? `${podcastTitle} 的其他單集` : "相關單集列表"}
          </h3>
          <p className="text-xs text-slate-400">點選即可立即切換、取得 MP3 來源及線上試聽</p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-indigo-400 border border-slate-700">
          共 {episodes.length} 集
        </span>
      </div>

      <div className="divide-y divide-slate-800/80 max-h-[480px] overflow-y-auto pr-1 space-y-1">
        {episodes.map((ep, idx) => {
          const isSelected = String(ep.id) === String(currentEpisodeId);
          const formattedDate = ep.releaseDate
            ? new Date(ep.releaseDate).toLocaleDateString("zh-TW")
            : "";

          return (
            <div
              key={ep.id || idx}
              onClick={() => onSelectEpisode(ep)}
              className={`p-3.5 rounded-2xl transition flex items-center justify-between gap-3 cursor-pointer group ${
                isSelected
                  ? "bg-indigo-950/70 border border-indigo-500/40 text-white"
                  : "hover:bg-slate-800/70 text-slate-200"
              }`}
            >
              <div className="flex items-center gap-3 min-w-0 flex-1">
                {ep.artworkUrl ? (
                  <img
                    src={ep.artworkUrl}
                    alt={ep.title}
                    className="w-11 h-11 rounded-xl object-cover border border-slate-700/60 shrink-0"
                  />
                ) : (
                  <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-indigo-400 font-mono text-xs shrink-0">
                    #{episodes.length - idx}
                  </div>
                )}

                <div className="min-w-0 flex-1">
                  <h4
                    className={`text-sm font-semibold truncate ${
                      isSelected ? "text-indigo-300" : "group-hover:text-white"
                    }`}
                  >
                    {ep.title}
                  </h4>
                  <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                    {formattedDate && <span>{formattedDate}</span>}
                    {ep.duration && (
                      <span className="flex items-center gap-1 font-mono text-[11px]">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {ep.duration}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons on hover */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={(e) => handleCopy(e, ep)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
                  title="複製此集 MP3 網址"
                >
                  {copiedId === ep.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>

                <a
                  href={`/api/download?url=${encodeURIComponent(ep.audioUrl)}&filename=${encodeURIComponent(
                    ep.title + ".mp3"
                  )}`}
                  download
                  onClick={(e) => e.stopPropagation()}
                  className="p-2 rounded-xl text-indigo-300 hover:text-white bg-indigo-950 hover:bg-indigo-900 border border-indigo-800/50 transition cursor-pointer"
                  title="下載此集 MP3"
                >
                  <Download className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
