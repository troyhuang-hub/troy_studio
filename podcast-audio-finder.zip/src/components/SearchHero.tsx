import React, { useState } from "react";
import { Search, Link as LinkIcon, Clipboard, ArrowRight, Loader2, Sparkles, CheckCircle2 } from "lucide-react";

interface SearchHeroProps {
  onSearch: (url: string) => void;
  isLoading: boolean;
  initialUrl?: string;
}

export const SearchHero: React.FC<SearchHeroProps> = ({
  onSearch,
  isLoading,
  initialUrl = "",
}) => {
  const [inputUrl, setInputUrl] = useState(initialUrl);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputUrl.trim()) {
      onSearch(inputUrl.trim());
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInputUrl(text.trim());
        onSearch(text.trim());
      }
    } catch {
      // clipboard permission denied or not available
    }
  };

  const userRequestedUrl =
    "https://podcasts.apple.com/tw/podcast/easy-japanese-podcast/id1550835265?l=en-GB&i=1000506799254";

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 p-6 sm:p-10 shadow-2xl">
      {/* Background Ambient Glow */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 max-w-3xl mx-auto text-center space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold">
          <Sparkles className="w-3.5 h-3.5" />
          <span>支援 Apple Podcasts 網址 / RSS Feed / 關鍵字搜尋</span>
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            輸入 Podcast 網址，立即取得 <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">MP3 來源位址</span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto">
            解析 Apple Podcast 頁面背後的真實音訊伺服器直鏈（CDN），支援即時線上試聽、無損原檔下載及單集資訊提取。
          </p>
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSubmit} className="relative group max-w-2xl mx-auto">
          <div className="relative flex items-center bg-slate-950/90 border-2 border-slate-700/80 group-focus-within:border-indigo-500 rounded-2xl shadow-xl transition-all overflow-hidden p-1.5">
            <div className="pl-3.5 text-slate-400">
              <LinkIcon className="w-5 h-5" />
            </div>

            <input
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="貼上 Apple Podcasts 網址 (如: https://podcasts.apple.com/...)"
              className="w-full bg-transparent px-3 py-3 text-sm text-white placeholder-slate-500 focus:outline-none"
              disabled={isLoading}
            />

            {/* Action buttons inside bar */}
            <div className="flex items-center gap-1.5 pr-1">
              {!inputUrl && (
                <button
                  type="button"
                  onClick={handlePaste}
                  className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer"
                  title="從剪貼簿貼上"
                >
                  <Clipboard className="w-3.5 h-3.5" />
                  <span>貼上</span>
                </button>
              )}

              <button
                type="submit"
                disabled={isLoading || !inputUrl.trim()}
                className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-sm font-semibold shadow-lg shadow-indigo-500/25 transition disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>解析中...</span>
                  </>
                ) : (
                  <>
                    <span>立即解析</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* Preset quick links */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-1 text-xs text-slate-400">
          <span className="text-slate-500">範例網址：</span>
          <button
            type="button"
            onClick={() => {
              setInputUrl(userRequestedUrl);
              onSearch(userRequestedUrl);
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 border border-indigo-700/50 transition cursor-pointer text-left"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="truncate max-w-[280px] sm:max-w-xs font-mono">
              EASY JAPANESE #002 (您提問的單集)
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
