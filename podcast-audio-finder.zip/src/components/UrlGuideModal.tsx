import React from "react";
import { X, HelpCircle, FileAudio, Rss, Layers, CheckCircle2, ExternalLink } from "lucide-react";

interface UrlGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UrlGuideModal: React.FC<UrlGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <HelpCircle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Podcast 音檔來源解析原理</h3>
            <p className="text-xs text-slate-400">了解 Apple Podcasts 背後的技術運作機制</p>
          </div>
        </div>

        <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-bold text-indigo-300 text-xs uppercase tracking-wider">
              <Layers className="w-4 h-4" />
              <span>1. Apple Podcasts 本身不儲存音檔</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Apple Podcasts 是一個索引目錄（Directory）。Podcast 創作者將節目音檔上傳至主機代管平台（例如 Podbean、Firstory、SoundOn、Spotify/Anchor、Buzzsprout），並產生一份 XML 格式的 RSS Feed。
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-bold text-indigo-300 text-xs uppercase tracking-wider">
              <Rss className="w-4 h-4" />
              <span>2. 網址中的代碼結構</span>
            </div>
            <p className="text-xs text-slate-400 font-mono bg-slate-900 p-2.5 rounded-lg break-all">
              https://podcasts.apple.com/.../id<span className="text-indigo-400 font-bold">1550835265</span>?i=<span className="text-emerald-400 font-bold">1000506799254</span>
            </p>
            <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
              <li><strong className="text-slate-200">id1550835265</strong>：代表整個 Podcast 節目（Collection ID）</li>
              <li><strong className="text-slate-200">i=1000506799254</strong>：代表該特定單集的音軌 ID（Track ID）</li>
            </ul>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-bold text-indigo-300 text-xs uppercase tracking-wider">
              <FileAudio className="w-4 h-4" />
              <span>3. 本工具如何抓取 MP3？</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              本工具會自動呼叫 Apple iTunes API 並精準抓取對應 RSS Feed，解析該單集節目的 <code className="text-indigo-400 font-mono">&lt;enclosure url="..." /&gt;</code> 標籤，取得創作者最原始的真實 CDN 直連 MP3 音訊位址，供您線上試聽或存檔下載。
            </p>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer shadow-lg shadow-indigo-600/20"
          >
            了解並關閉
          </button>
        </div>
      </div>
    </div>
  );
};
