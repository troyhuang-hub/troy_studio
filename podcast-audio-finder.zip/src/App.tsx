import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { SearchHero } from "./components/SearchHero";
import { ResolvedEpisodeCard } from "./components/ResolvedEpisodeCard";
import { EpisodeList } from "./components/EpisodeList";
import { UrlGuideModal } from "./components/UrlGuideModal";
import { EpisodeInfo, PodcastInfo, ResolveResponse } from "./types";
import { AlertCircle, Music2, Sparkles, CheckCircle2, ShieldCheck, Zap } from "lucide-react";

const INITIAL_REQUEST_URL =
  "https://podcasts.apple.com/tw/podcast/easy-japanese-podcast/id1550835265?l=en-GB&i=1000506799254";

export default function App() {
  const [urlInput, setUrlInput] = useState(INITIAL_REQUEST_URL);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentEpisode, setCurrentEpisode] = useState<EpisodeInfo | null>(null);
  const [currentPodcast, setCurrentPodcast] = useState<PodcastInfo | null>(null);
  const [episodeList, setEpisodeList] = useState<EpisodeInfo[]>([]);
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  const resolvePodcast = async (targetUrl: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/resolve-podcast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: targetUrl }),
      });

      const data: ResolveResponse = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || "無法解析此 Podcast 網址，請確認網址是否正確。");
      }

      if (data.type === "apple-podcast-episode" && data.episode) {
        setCurrentEpisode(data.episode);
        setCurrentPodcast(data.podcast || null);
        setEpisodeList(data.recentEpisodes || []);
      } else if (data.type === "apple-podcast-channel" || data.type === "rss-feed") {
        if (data.featuredEpisode) {
          setCurrentEpisode(data.featuredEpisode);
        } else if (data.episodes && data.episodes.length > 0) {
          setCurrentEpisode(data.episodes[0]);
        }
        setCurrentPodcast(data.podcast || (data as any).channel || null);
        setEpisodeList(data.episodes || []);
      } else if (data.type === "direct-audio" && data.episode) {
        setCurrentEpisode(data.episode);
        setCurrentPodcast(null);
        setEpisodeList([]);
      }
    } catch (err: any) {
      console.error("Resolve error:", err);
      setError(err.message || "發生未知錯誤，請稍後再試。");
    } finally {
      setIsLoading(false);
    }
  };

  // Automatically resolve the user's requested podcast episode on initial load
  useEffect(() => {
    resolvePodcast(INITIAL_REQUEST_URL);
  }, []);

  const handleSelectEpisode = (ep: EpisodeInfo) => {
    setCurrentEpisode(ep);
    // Smooth scroll to top of episode card
    window.scrollTo({ top: 380, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      <Header onOpenGuide={() => setIsGuideOpen(true)} />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Search Hero Area */}
        <SearchHero
          onSearch={(url) => {
            setUrlInput(url);
            resolvePodcast(url);
          }}
          isLoading={isLoading}
          initialUrl={urlInput}
        />

        {/* Error Alert */}
        {error && (
          <div className="bg-rose-950/80 border border-rose-800 rounded-2xl p-4 flex items-center gap-3 text-rose-200 text-sm">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <p className="flex-1">{error}</p>
            <button
              onClick={() => resolvePodcast(urlInput)}
              className="px-3 py-1.5 rounded-lg bg-rose-900 hover:bg-rose-800 text-xs font-semibold cursor-pointer"
            >
              重試
            </button>
          </div>
        )}

        {/* Resolved Episode Main Section */}
        {currentEpisode ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            <div className="lg:col-span-2 space-y-6">
              <ResolvedEpisodeCard
                episode={currentEpisode}
                podcast={currentPodcast || undefined}
              />
            </div>

            {/* Sidebar with related / channel episodes */}
            <div className="lg:col-span-1 space-y-6">
              {episodeList.length > 0 ? (
                <EpisodeList
                  episodes={episodeList}
                  currentEpisodeId={currentEpisode.id}
                  onSelectEpisode={handleSelectEpisode}
                  podcastTitle={currentPodcast?.title || currentEpisode.podcastTitle}
                />
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
                  <div className="flex items-center gap-2 font-bold text-white text-sm">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>音訊來源驗證說明</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    本系統直接連接至創作者原廠儲存 CDN（Podbean S3 叢集），音質未經任何二度壓縮，可確保最高 100% 原音輸出。
                  </p>
                </div>
              )}

              {/* Quick Feature Info Cards */}
              <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/20 rounded-3xl p-6 space-y-3">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase tracking-wider">
                  <Zap className="w-4 h-4" />
                  <span>支援功能</span>
                </div>
                <ul className="text-xs text-slate-300 space-y-2">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>即時一鍵複製 MP3 來源直鏈</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>內建 0.8x~2.0x 變速及快轉試聽播放器</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>支援瀏覽該 Podcast 頻道所有歷史單集</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>可直接下載 .mp3 實體檔案至電腦與手機</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        ) : (
          !isLoading && (
            <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-3xl space-y-3">
              <Music2 className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-lg font-bold text-slate-300">尚未載入音檔</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                請在上方輸入框貼上 Apple Podcasts 網址或點選範例快速解析。
              </p>
            </div>
          )
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p>Podcast Audio Finder · 支援 Apple Podcasts, Podbean, Spotify, RSS 音檔來源解析</p>
      </footer>

      {/* Guide Modal */}
      <UrlGuideModal isOpen={isGuideOpen} onClose={() => setIsGuideOpen(false)} />
    </div>
  );
}
