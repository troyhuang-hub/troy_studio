export interface EpisodeInfo {
  id: string | number;
  title: string;
  podcastTitle: string;
  podcastId?: string;
  artworkUrl?: string;
  audioUrl: string;
  duration?: number | string;
  releaseDate?: string;
  description?: string;
  fileExtension?: string;
  fileSize?: string;
  feedUrl?: string;
  sourceType: "apple-podcast" | "rss-feed" | "direct-audio" | "itunes-search";
}

export interface PodcastInfo {
  id: string | number;
  title: string;
  artist?: string;
  artworkUrl?: string;
  feedUrl?: string;
  genres?: { name: string; id: string }[];
  episodeCount?: number;
  totalEpisodes?: number;
}

export interface ResolveResponse {
  success: boolean;
  type: "apple-podcast-episode" | "apple-podcast-channel" | "rss-feed" | "direct-audio" | "search-results";
  podcast?: PodcastInfo;
  channel?: PodcastInfo;
  episode?: EpisodeInfo;
  featuredEpisode?: EpisodeInfo;
  episodes?: EpisodeInfo[];
  recentEpisodes?: EpisodeInfo[];
  results?: any[];
  error?: string;
}

export interface AudioInspection {
  status: number;
  contentType: string;
  contentLength: number | null;
  formattedSize: string;
  acceptRanges?: string | null;
  redirectedUrl?: string | null;
}
